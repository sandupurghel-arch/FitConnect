# FitConnect MVP

A web platform to help users organize fitness meetups and wellness events
(running clubs, yoga classes, group hikes). Built as an 8-week Agile/Scrum
project for SWE6301 Agile Programming.

## MVP Features

| # | Feature | App |
|---|---|---|
| 1 | User Registration and Login | `accounts` |
| 2 | Event/Meetup Creation and Editing | `events` |
| 3 | RSVP System (join / cancel) | `events` |
| 4 | Dashboard showing upcoming sessions | `dashboard` |
| 5 | Notifications (in-app + email reminders) | `notifications` |

## Tech stack

- **Backend:** Django 5 (Python)
- **Database:** SQLite (dev/demo) — swap `DATABASES` in `settings.py` for Postgres/MySQL in production
- **Frontend:** Django templates + Bootstrap 5
- **Testing:** Django's built-in test runner (`unittest` under the hood)

## Local setup

```bash
# 1. Clone and enter the project
cd fitconnect

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Apply migrations
python manage.py makemigrations
python manage.py migrate

# 5. Create an admin user (optional, for /admin/)
python manage.py createsuperuser

# 6. Run the dev server
python manage.py runserver
```

Visit `http://127.0.0.1:8000/accounts/register/` to create an account.

## Running tests

```bash
python manage.py test
```

Tests cover all five MVP features: registration/login, event creation/editing
(with organizer-only permission checks), RSVP join/cancel (including the
full-capacity edge case), the dashboard, and the notification/reminder system
(including the "don't double-notify" and "no reminder outside the 24h window"
edge cases).

## Sending event reminders

Reminders (in-app + email) are sent via a management command, meant to be run
on a schedule (e.g. cron, or a Task Scheduler job every 30–60 minutes):

```bash
python manage.py send_reminders
```

In dev, emails are printed to the console (`EMAIL_BACKEND` is the console
backend in `settings.py`) rather than actually sent — swap in SMTP credentials
before deploying.

## Project structure

```
fitconnect/
├── fitconnect/       # project settings, root urls
├── accounts/         # registration, login, profile
├── events/           # event CRUD, RSVP
├── dashboard/        # "my upcoming sessions" view
├── notifications/    # in-app notifications + reminder command
├── templates/        # shared base template
└── static/           # shared CSS
```

## Agile process

This repo's commit history is organized by sprint (see `git log`). Each
sprint's goal, planning notes, and retrospective are documented in the
Individual Report / Agile Project Delivery Report, not in this README, to
avoid duplicating evidence across deliverables.
