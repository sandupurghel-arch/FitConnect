from django.conf import settings
from django.db import models


class Notification(models.Model):
    """In-app notifications (FitConnect MVP feature #5)."""

    class Type(models.TextChoices):
        RSVP_UPDATE = 'rsvp_update', 'RSVP update'
        REMINDER = 'reminder', 'Upcoming event reminder'
        EVENT_UPDATE = 'event_update', 'Event details changed'

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications'
    )
    event = models.ForeignKey(
        'events.Event', on_delete=models.CASCADE, related_name='notifications',
        null=True, blank=True,
    )
    notification_type = models.CharField(max_length=20, choices=Type.choices)
    message = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.notification_type}] {self.message[:40]}"
