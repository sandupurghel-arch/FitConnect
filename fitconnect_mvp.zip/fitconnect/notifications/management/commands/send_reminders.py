from datetime import timedelta

from django.core.mail import send_mail
from django.core.management.base import BaseCommand
from django.utils import timezone

from events.models import RSVP
from notifications.models import Notification


class Command(BaseCommand):
    """
    Sends reminders (email + in-app) for events starting in the next 24 hours.

    Intended to be run periodically (e.g. via cron / a scheduled task):
        python manage.py send_reminders
    """

    help = 'Send email and in-app reminders for events starting within 24 hours.'

    def handle(self, *args, **options):
        window_start = timezone.now()
        window_end = window_start + timedelta(hours=24)

        upcoming_rsvps = RSVP.objects.filter(
            status=RSVP.Status.GOING,
            event__start_time__gte=window_start,
            event__start_time__lte=window_end,
        ).select_related('event', 'user')

        sent_count = 0
        for rsvp in upcoming_rsvps:
            already_reminded = Notification.objects.filter(
                user=rsvp.user, event=rsvp.event, notification_type=Notification.Type.REMINDER,
            ).exists()
            if already_reminded:
                continue

            message = (
                f"Reminder: '{rsvp.event.title}' starts at "
                f"{rsvp.event.start_time:%d %b %Y %H:%M} at {rsvp.event.location}."
            )
            Notification.objects.create(
                user=rsvp.user, event=rsvp.event,
                notification_type=Notification.Type.REMINDER, message=message,
            )

            if rsvp.user.profile.email_reminders_enabled and rsvp.user.email:
                send_mail(
                    subject=f"Reminder: {rsvp.event.title} is coming up",
                    message=message,
                    from_email=None,  # uses DEFAULT_FROM_EMAIL
                    recipient_list=[rsvp.user.email],
                    fail_silently=True,
                )
            sent_count += 1

        self.stdout.write(self.style.SUCCESS(f"Sent {sent_count} reminder(s)."))
