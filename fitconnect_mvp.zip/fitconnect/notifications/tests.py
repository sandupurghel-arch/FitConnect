from datetime import timedelta
from io import StringIO

from django.contrib.auth.models import User
from django.core import mail
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from events.models import RSVP, Event

from .models import Notification


class NotificationViewTests(TestCase):

    def setUp(self):
        self.user = User.objects.create_user('nina', password='pass12345')
        self.client.login(username='nina', password='pass12345')

    def test_notification_list_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse('notifications:list'))
        self.assertEqual(response.status_code, 302)

    def test_mark_read_updates_notification(self):
        notification = Notification.objects.create(
            user=self.user, notification_type=Notification.Type.REMINDER, message='Test'
        )
        self.client.post(reverse('notifications:mark_read', args=[notification.pk]))
        notification.refresh_from_db()
        self.assertTrue(notification.is_read)


class SendRemindersCommandTests(TestCase):
    """Exploratory/edge-case testing for the reminder scheduling command."""

    def setUp(self):
        self.organizer = User.objects.create_user('organizer', password='pass12345')
        self.member = User.objects.create_user(
            'member', password='pass12345', email='member@example.com'
        )

    def test_sends_reminder_for_event_within_24_hours(self):
        event = Event.objects.create(
            organizer=self.organizer, title='Morning Run', location='Park',
            start_time=timezone.now() + timedelta(hours=5),
        )
        RSVP.objects.create(event=event, user=self.member, status=RSVP.Status.GOING)

        out = StringIO()
        call_command('send_reminders', stdout=out)

        self.assertTrue(
            Notification.objects.filter(
                user=self.member, event=event, notification_type=Notification.Type.REMINDER
            ).exists()
        )
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn('Morning Run', mail.outbox[0].subject)

    def test_no_reminder_for_event_outside_window(self):
        """Edge case: an event 3 days away should not trigger a reminder yet."""
        event = Event.objects.create(
            organizer=self.organizer, title='Next Week Hike', location='Hills',
            start_time=timezone.now() + timedelta(days=3),
        )
        RSVP.objects.create(event=event, user=self.member, status=RSVP.Status.GOING)

        call_command('send_reminders', stdout=StringIO())

        self.assertFalse(Notification.objects.filter(event=event).exists())
        self.assertEqual(len(mail.outbox), 0)

    def test_no_duplicate_reminder_on_repeated_runs(self):
        """Edge case: running the command twice shouldn't double-notify."""
        event = Event.objects.create(
            organizer=self.organizer, title='Evening Yoga', location='Studio',
            start_time=timezone.now() + timedelta(hours=2),
        )
        RSVP.objects.create(event=event, user=self.member, status=RSVP.Status.GOING)

        call_command('send_reminders', stdout=StringIO())
        call_command('send_reminders', stdout=StringIO())

        self.assertEqual(
            Notification.objects.filter(event=event, user=self.member).count(), 1
        )

    def test_cancelled_rsvp_gets_no_reminder(self):
        """Edge case: a cancelled RSVP should not receive a reminder."""
        event = Event.objects.create(
            organizer=self.organizer, title='Cancelled Attendance Event', location='Gym',
            start_time=timezone.now() + timedelta(hours=3),
        )
        RSVP.objects.create(event=event, user=self.member, status=RSVP.Status.CANCELLED)

        call_command('send_reminders', stdout=StringIO())

        self.assertFalse(Notification.objects.filter(event=event).exists())
