from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.utils import timezone

from events.models import RSVP, Event


@login_required
def home(request):
    """Dashboard showing upcoming sessions (FitConnect MVP feature #4)."""
    now = timezone.now()

    organized_upcoming = Event.objects.filter(
        organizer=request.user, start_time__gte=now
    ).order_by('start_time')

    attending_upcoming = Event.objects.filter(
        rsvps__user=request.user,
        rsvps__status=RSVP.Status.GOING,
        start_time__gte=now,
    ).order_by('start_time').distinct()

    recommended = Event.objects.filter(
        start_time__gte=now,
        category=request.user.profile.favourite_activity,
    ).exclude(
        organizer=request.user
    ).exclude(
        rsvps__user=request.user, rsvps__status=RSVP.Status.GOING
    ).order_by('start_time')[:5]

    context = {
        'organized_upcoming': organized_upcoming,
        'attending_upcoming': attending_upcoming,
        'recommended': recommended,
    }
    return render(request, 'dashboard/home.html', context)
