from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from events.models import RSVP, Event


class DashboardTests(TestCase):
    """Tests for the Dashboard showing upcoming sessions (MVP feature #4)."""

    def setUp(self):
        self.user = User.objects.create_user('dashuser', password='pass12345')
        self.client.login(username='dashuser', password='pass12345')

    def test_dashboard_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse('dashboard:home'))
        self.assertEqual(response.status_code, 302)

    def test_dashboard_lists_organized_events(self):
        Event.objects.create(
            organizer=self.user, title='My Own Event', location='Home turf',
            start_time=timezone.now() + timedelta(days=1),
        )
        response = self.client.get(reverse('dashboard:home'))
        self.assertContains(response, 'My Own Event')

    def test_dashboard_lists_attending_events(self):
        organizer = User.objects.create_user('organizer2', password='pass12345')
        event = Event.objects.create(
            organizer=organizer, title='Community Yoga', location='Studio',
            start_time=timezone.now() + timedelta(days=2),
        )
        RSVP.objects.create(event=event, user=self.user, status=RSVP.Status.GOING)
        response = self.client.get(reverse('dashboard:home'))
        self.assertContains(response, 'Community Yoga')

    def test_dashboard_excludes_past_events(self):
        Event.objects.create(
            organizer=self.user, title='Old Event', location='Somewhere',
            start_time=timezone.now() - timedelta(days=5),
        )
        response = self.client.get(reverse('dashboard:home'))
        self.assertNotContains(response, 'Old Event')
