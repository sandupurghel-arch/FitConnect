from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Profile


class RegistrationTests(TestCase):
    """Unit tests for FitConnect MVP feature #1: Registration and Login."""

    def test_profile_auto_created_on_registration(self):
        """A Profile should be created automatically via the post_save signal."""
        user = User.objects.create_user(username='alice', password='StrongPass123')
        self.assertTrue(Profile.objects.filter(user=user).exists())

    def test_registration_view_creates_user_and_logs_in(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'bob',
            'email': 'bob@example.com',
            'password1': 'Or4ngeCounty!',
            'password2': 'Or4ngeCounty!',
        })
        self.assertEqual(User.objects.filter(username='bob').count(), 1)
        # Successful registration logs the user in and redirects to edit profile.
        self.assertRedirects(response, reverse('accounts:edit_profile'))

    def test_registration_rejects_mismatched_passwords(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'carol',
            'email': 'carol@example.com',
            'password1': 'Or4ngeCounty!',
            'password2': 'DifferentPass!',
        })
        self.assertEqual(User.objects.filter(username='carol').count(), 0)
        self.assertEqual(response.status_code, 200)  # re-renders form with errors

    def test_login_required_for_profile_edit(self):
        response = self.client.get(reverse('accounts:edit_profile'))
        self.assertEqual(response.status_code, 302)  # redirected to login

    def test_logged_in_user_can_update_profile(self):
        user = User.objects.create_user(username='dave', password='StrongPass123')
        self.client.login(username='dave', password='StrongPass123')
        response = self.client.post(reverse('accounts:edit_profile'), {
            'bio': 'I love parkrun on Saturdays.',
            'home_city': 'Bristol',
            'favourite_activity': 'running',
            'email_reminders_enabled': True,
        })
        self.assertRedirects(response, reverse('dashboard:home'))
        user.profile.refresh_from_db()
        self.assertEqual(user.profile.home_city, 'Bristol')
