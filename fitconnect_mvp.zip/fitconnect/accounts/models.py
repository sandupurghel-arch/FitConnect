from django.conf import settings
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver


class Profile(models.Model):
    """
    Extra FitConnect-specific info attached to Django's built-in User.

    Kept separate from User (rather than a custom User model) so the MVP
    can rely on Django's battle-tested auth system for registration/login,
    while still letting users record what kind of activities they're into.
    """

    ACTIVITY_CHOICES = [
        ('running', 'Running'),
        ('yoga', 'Yoga'),
        ('hiking', 'Hiking'),
        ('cycling', 'Cycling'),
        ('general', 'General wellness'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile'
    )
    bio = models.CharField(max_length=255, blank=True)
    home_city = models.CharField(max_length=100, blank=True)
    favourite_activity = models.CharField(
        max_length=20, choices=ACTIVITY_CHOICES, default='general'
    )
    email_reminders_enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile<{self.user.username}>"


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_or_update_profile(sender, instance, created, **kwargs):
    """Auto-create a Profile the moment a new User registers."""
    if created:
        Profile.objects.create(user=instance)
    else:
        # Guard against users created before this signal existed.
        Profile.objects.get_or_create(user=instance)
