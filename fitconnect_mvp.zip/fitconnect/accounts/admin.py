from django.contrib import admin

from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'home_city', 'favourite_activity', 'email_reminders_enabled')
    search_fields = ('user__username', 'home_city')
