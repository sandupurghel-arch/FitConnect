from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from notifications.models import Notification

from .models import RSVP, Event


def future_time(hours=48):
    return timezone.now() + timedelta(hours=hours)


class EventModelTests(TestCase):
    """Unit tests for the Event model (capacity / spots logic)."""

    def setUp(self):
        self.organizer = User.objects.create_user('organizer', password='pass12345')
        self.event = Event.objects.create(
            organizer=self.organizer,
            title='Saturday Parkrun',
            category='running',
            location='Bristol Downs',
            start_time=future_time(),
            capacity=2,
        )

    def test_spots_remaining_with_no_rsvps(self):
        self.assertEqual(self.event.spots_remaining, 2)

    def test_spots_remaining_decreases_with_confirmed_rsvp(self):
        attendee = User.objects.create_user('attendee1', password='pass12345')
        RSVP.objects.create(event=self.event, user=attendee, status=RSVP.Status.GOING)
        self.assertEqual(self.event.spots_remaining, 1)

    def test_unlimited_capacity_when_none(self):
        self.event.capacity = None
        self.event.save()
        self.assertIsNone(self.event.spots_remaining)
        self.assertFalse(self.event.is_full())


class EventCreateEditTests(TestCase):
    """Acceptance tests: Event/Meetup Creation and Editing (MVP feature #2)."""

    def setUp(self):
        self.organizer = User.objects.create_user('organizer', password='pass12345')
        self.other_user = User.objects.create_user('other', password='pass12345')
        self.client.login(username='organizer', password='pass12345')

    def test_authenticated_user_can_create_event(self):
        response = self.client.post(reverse('events:event_create'), {
            'title': 'Sunrise Yoga',
            'category': 'yoga',
            'description': 'Gentle flow for all levels.',
            'location': 'Riverside Park',
            'start_time': future_time().strftime('%Y-%m-%dT%H:%M'),
            'capacity': 15,
        })
        self.assertEqual(Event.objects.filter(title='Sunrise Yoga').count(), 1)
        event = Event.objects.get(title='Sunrise Yoga')
        self.assertEqual(event.organizer, self.organizer)
        self.assertRedirects(response, event.get_absolute_url())

    def test_cannot_create_event_with_past_start_time(self):
        response = self.client.post(reverse('events:event_create'), {
            'title': 'Time Travellers Hike',
            'category': 'hiking',
            'description': '',
            'location': 'Nowhere',
            'start_time': (timezone.now() - timedelta(days=1)).strftime('%Y-%m-%dT%H:%M'),
            'capacity': '',
        })
        self.assertEqual(Event.objects.filter(title='Time Travellers Hike').count(), 0)
        self.assertContains(response, "can&#x27;t be in the past")

    def test_only_organizer_can_edit_event(self):
        event = Event.objects.create(
            organizer=self.organizer, title='Trail Run', location='Forest',
            start_time=future_time(),
        )
        self.client.logout()
        self.client.login(username='other', password='pass12345')
        response = self.client.get(reverse('events:event_update', args=[event.pk]))
        self.assertEqual(response.status_code, 403)

    def test_organizer_can_edit_event(self):
        event = Event.objects.create(
            organizer=self.organizer, title='Trail Run', location='Forest',
            start_time=future_time(),
        )
        response = self.client.post(reverse('events:event_update', args=[event.pk]), {
            'title': 'Trail Run (Updated)',
            'category': 'running',
            'description': 'Now with hills.',
            'location': 'Forest',
            'start_time': future_time().strftime('%Y-%m-%dT%H:%M'),
            'capacity': '',
        })
        event.refresh_from_db()
        self.assertEqual(event.title, 'Trail Run (Updated)')


class RSVPTests(TestCase):
    """Acceptance tests: RSVP System (MVP feature #3), ATDD-style given/when/then."""

    def setUp(self):
        self.organizer = User.objects.create_user('organizer', password='pass12345')
        self.member = User.objects.create_user('member', password='pass12345')
        self.event = Event.objects.create(
            organizer=self.organizer, title='Group Hike', location='Peak District',
            start_time=future_time(), capacity=1,
        )
        self.client.login(username='member', password='pass12345')

    def test_member_can_join_event(self):
        """
        GIVEN a logged-in member and an event with free capacity
        WHEN they hit the RSVP toggle
        THEN an RSVP with status 'going' is created and the organizer is notified.
        """
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))
        rsvp = RSVP.objects.get(event=self.event, user=self.member)
        self.assertEqual(rsvp.status, RSVP.Status.GOING)
        self.assertTrue(
            Notification.objects.filter(user=self.organizer, event=self.event).exists()
        )

    def test_member_can_cancel_rsvp(self):
        """
        GIVEN a member who already RSVP'd
        WHEN they hit the RSVP toggle again
        THEN their RSVP status flips to 'cancelled' and their spot is freed.
        """
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))  # join
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))  # cancel
        rsvp = RSVP.objects.get(event=self.event, user=self.member)
        self.assertEqual(rsvp.status, RSVP.Status.CANCELLED)
        self.assertEqual(self.event.spots_remaining, 1)

    def test_join_creates_exactly_one_notification(self):
        """
        Regression test: an earlier version of rsvp_toggle saved the RSVP
        object twice on creation, which fired the post_save notification
        signal twice and sent the organizer a duplicate notification. This
        pins the fix in place.
        """
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))
        self.assertEqual(
            Notification.objects.filter(user=self.organizer, event=self.event).count(), 1
        )

    def test_cannot_join_full_event(self):
        """
        GIVEN an event at full capacity
        WHEN a different member tries to RSVP
        THEN they are turned away and no RSVP is created for them.
        """
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))  # fills the 1 spot

        second_member = User.objects.create_user('second_member', password='pass12345')
        self.client.logout()
        self.client.login(username='second_member', password='pass12345')
        self.client.post(reverse('events:rsvp_toggle', args=[self.event.pk]))

        self.assertFalse(RSVP.objects.filter(event=self.event, user=second_member).exists())
