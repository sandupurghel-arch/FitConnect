from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone


class Event(models.Model):
    """A fitness meetup / wellness event (FitConnect MVP feature #2)."""

    CATEGORY_CHOICES = [
        ('running', 'Running club'),
        ('yoga', 'Yoga class'),
        ('hiking', 'Group hike'),
        ('cycling', 'Cycling'),
        ('other', 'Other wellness event'),
    ]

    organizer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='organized_events'
    )
    title = models.CharField(max_length=150)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='other')
    description = models.TextField(blank=True)
    location = models.CharField(max_length=255)
    start_time = models.DateTimeField()
    capacity = models.PositiveIntegerField(
        null=True, blank=True, help_text='Leave blank for unlimited spots.'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['start_time']

    def __str__(self):
        return f"{self.title} ({self.start_time:%d %b %Y %H:%M})"

    def get_absolute_url(self):
        return reverse('events:event_detail', args=[self.pk])

    @property
    def is_upcoming(self):
        return self.start_time >= timezone.now()

    @property
    def confirmed_attendee_count(self):
        return self.rsvps.filter(status=RSVP.Status.GOING).count()

    @property
    def spots_remaining(self):
        if self.capacity is None:
            return None
        return max(self.capacity - self.confirmed_attendee_count, 0)

    def is_full(self):
        return self.capacity is not None and self.spots_remaining == 0


class RSVP(models.Model):
    """RSVP System: join or cancel participation (FitConnect MVP feature #3)."""

    class Status(models.TextChoices):
        GOING = 'going', 'Going'
        CANCELLED = 'cancelled', 'Cancelled'

    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='rsvps')
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='rsvps'
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.GOING)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('event', 'user')

    def __str__(self):
        return f"{self.user.username} -> {self.event.title} [{self.status}]"
