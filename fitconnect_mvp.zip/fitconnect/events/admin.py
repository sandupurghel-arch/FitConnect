from django.contrib import admin

from .models import RSVP, Event


class RSVPInline(admin.TabularInline):
    model = RSVP
    extra = 0


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'organizer', 'start_time', 'confirmed_attendee_count')
    list_filter = ('category',)
    search_fields = ('title', 'location')
    inlines = [RSVPInline]


@admin.register(RSVP)
class RSVPAdmin(admin.ModelAdmin):
    list_display = ('event', 'user', 'status', 'updated_at')
    list_filter = ('status',)
