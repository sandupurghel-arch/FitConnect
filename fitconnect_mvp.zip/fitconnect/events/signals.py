from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import RSVP


@receiver(post_save, sender=RSVP)
def notify_organizer_of_rsvp_change(sender, instance, created, **kwargs):
    """
    Notifications (FitConnect MVP feature #5): let the event organizer know
    when someone joins or cancels their event.
    """
    from notifications.models import Notification  # local import avoids circular app-loading

    if instance.user_id == instance.event.organizer_id:
        return  # organizer RSVPing to their own event isn't notification-worthy

    if created or instance.status == RSVP.Status.GOING:
        message = f"{instance.user.username} is going to your event '{instance.event.title}'."
    else:
        message = f"{instance.user.username} cancelled their spot for '{instance.event.title}'."

    Notification.objects.create(
        user=instance.event.organizer,
        event=instance.event,
        notification_type=Notification.Type.RSVP_UPDATE,
        message=message,
    )
