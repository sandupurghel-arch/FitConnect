from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .forms import EventForm
from .models import RSVP, Event


class EventListView(LoginRequiredMixin, ListView):
    """Event/Meetup listing - lets members browse upcoming meetups."""

    model = Event
    template_name = 'events/event_list.html'
    context_object_name = 'events'
    paginate_by = 10

    def get_queryset(self):
        qs = Event.objects.select_related('organizer').all()
        category = self.request.GET.get('category')
        if category:
            qs = qs.filter(category=category)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['categories'] = Event.CATEGORY_CHOICES
        ctx['selected_category'] = self.request.GET.get('category', '')
        return ctx


class EventDetailView(LoginRequiredMixin, DetailView):
    model = Event
    template_name = 'events/event_detail.html'
    context_object_name = 'event'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        ctx['user_rsvp'] = self.object.rsvps.filter(user=user).first()
        ctx['attendees'] = self.object.rsvps.filter(status=RSVP.Status.GOING).select_related('user')
        return ctx


class EventCreateView(LoginRequiredMixin, CreateView):
    """Event/Meetup Creation (FitConnect MVP feature #2)."""

    model = Event
    form_class = EventForm
    template_name = 'events/event_form.html'

    def form_valid(self, form):
        form.instance.organizer = self.request.user
        messages.success(self.request, "Event created.")
        return super().form_valid(form)


class EventUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    """Event editing - restricted to the organizer (FitConnect MVP feature #2)."""

    model = Event
    form_class = EventForm
    template_name = 'events/event_form.html'

    def test_func(self):
        event = self.get_object()
        return event.organizer_id == self.request.user.id

    def form_valid(self, form):
        messages.success(self.request, "Event updated.")
        return super().form_valid(form)


class EventDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Event
    template_name = 'events/event_confirm_delete.html'
    success_url = reverse_lazy('events:event_list')

    def test_func(self):
        event = self.get_object()
        return event.organizer_id == self.request.user.id


@login_required
def rsvp_toggle(request, pk):
    """RSVP System: join or cancel participation (FitConnect MVP feature #3)."""
    event = get_object_or_404(Event, pk=pk)
    rsvp = RSVP.objects.filter(event=event, user=request.user).first()

    if rsvp is None:
        # Brand new RSVP -> capacity must be checked *before* creating the row.
        if event.is_full():
            messages.error(request, "Sorry, this event is now full.")
            return redirect('events:event_detail', pk=pk)
        RSVP.objects.create(event=event, user=request.user, status=RSVP.Status.GOING)
        messages.success(request, f"You're going to {event.title}!")
    elif rsvp.status == RSVP.Status.GOING:
        # Already going -> cancel. No capacity check needed to free up a spot.
        rsvp.status = RSVP.Status.CANCELLED
        rsvp.save()
        messages.info(request, f"You've cancelled your spot for {event.title}.")
    else:
        # Re-joining after a previous cancellation -> check capacity again.
        if event.is_full():
            messages.error(request, "Sorry, this event is now full.")
            return redirect('events:event_detail', pk=pk)
        rsvp.status = RSVP.Status.GOING
        rsvp.save()
        messages.success(request, f"You're going to {event.title}!")

    return redirect('events:event_detail', pk=pk)
